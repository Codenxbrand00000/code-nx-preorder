# CODE.NX - Website Pre-Order Siap Jalan

## 🔧 Cara Setup:

### 1. Setup Google Sheets

1. Buat Google Sheet baru → beri nama "PreOrder CODE.NX"
2. Tambahkan kolom: Tanggal, Nama, Email, Ukuran
3. Klik `Extensions → Apps Script`
4. Hapus semua isi editor, lalu paste isi dari `google-script.gs`
5. Klik `Deploy → New Deployment → Web App`
   - Execute as: Me
   - Access: Anyone
6. Salin URL Web App dan paste ke dalam `index.tsx`, bagian:
   ```ts
   const res = await fetch('PASTE_URL_DISINI', { ... });
   ```

### 2. Jalankan Website

1. Upload folder ini ke GitHub sebagai `code-nx-preorder`
2. Deploy ke Vercel: https://vercel.com → "Import GitHub Repo"
3. Website kamu akan online dan siap mencatat pre-order ke Google Sheets!

---

✅ Tidak perlu backend, serverless, simple, bisa custom style dan branding!
