import { useState } from 'react';

export default function Home() {
  const [form, setForm] = useState({ nama: '', email: '', ukuran: 'M' });
  const [status, setStatus] = useState('');

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async e => {
    e.preventDefault();
    setStatus('loading');

    const res = await fetch('https://script.google.com/macros/s/YOUR_SCRIPT_ID_HERE/exec', {
      method: 'POST',
      body: JSON.stringify(form),
      headers: { 'Content-Type': 'application/json' },
    });

    if (res.ok) setStatus('success');
    else setStatus('error');
  };

  return (
    <main style={{ padding: 40, fontFamily: 'sans-serif' }}>
      <h1>Pre-Order CODE.NX.0001.BETA</h1>
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 10, maxWidth: 400 }}>
        <input name="nama" placeholder="Nama Lengkap" onChange={handleChange} required />
        <input name="email" placeholder="Email" type="email" onChange={handleChange} required />
        <select name="ukuran" onChange={handleChange} defaultValue="M">
          <option value="S">S</option><option value="M">M</option><option value="L">L</option><option value="XL">XL</option>
        </select>
        <button type="submit">Kirim Pre-Order</button>
      </form>
      {status === 'loading' && <p>⏳ Mengirim...</p>}
      {status === 'success' && <p>✅ Terima kasih! Data kamu sudah masuk.</p>}
      {status === 'error' && <p>❌ Gagal mengirim. Coba lagi.</p>}
    </main>
  );
}
